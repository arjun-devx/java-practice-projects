package dev.arjun.DemoAPIProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoApiProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
