package dev.arjun.DemoAPIProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoApiProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApiProjectApplication.class, args);
	}

}
